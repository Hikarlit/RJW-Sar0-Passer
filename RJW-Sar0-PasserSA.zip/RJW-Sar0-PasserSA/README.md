# SizedApparel-Passer

Passer Race（`Chinon.Passer`）的 Sized Apparel 支援补丁。为 Passer Race 提供 Sized Apparel 的身体部位贴图。
## 依赖

| Mod | packageId |
| --- | --- |
| Passer Race | `Chinon.Passer` |
| Sized Apparel for RJW (SAR version) | `OTYOTY.SizedApparel` |

## 作者

Hikarlit
